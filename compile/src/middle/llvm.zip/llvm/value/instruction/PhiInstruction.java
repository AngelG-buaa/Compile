package middle.llvm.value.instruction;

import middle.llvm.type.IRType;
import middle.llvm.value.IRValue;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * LLVM IR Phi指令
 * <result> = phi [fast-math-flags] <ty> [<val0>, <label0>], ...
 * Phi指令只能出现在基本块的开头，用于SSA形式中的值合并
 */
public class PhiInstruction extends IRInstruction {
    private final Map<IRValue, IRValue> incomingValues; // 基本块 -> 对应的值
    
    public PhiInstruction(IRValue parentBlock, int nameCounter, IRType resultType, List<IRValue> predecessorBlocks) {
        super(parentBlock, "%phi" + nameCounter, resultType);
        this.incomingValues = new LinkedHashMap<>();
        
        // 初始化时为每个前驱基本块添加null值占位符
        for (IRValue block : predecessorBlocks) {
            incomingValues.put(block, null);
            addOperand(null); // 添加null占位符
        }
    }
    
    /**
     * 获取前驱基本块列表
     */
    public List<IRValue> getPredecessorBlocks() {
        return new ArrayList<>(incomingValues.keySet());
    }
    
    /**
     * 获取所有传入值
     */
    public List<IRValue> getIncomingValues() {
        return new ArrayList<>(incomingValues.values());
    }
    
    /**
     * 填充指定基本块对应的值
     */
    public void fillIncomingValue(IRValue value, IRValue fromBlock) {
        if (incomingValues.containsKey(fromBlock)) {
            IRValue oldValue = incomingValues.get(fromBlock);
            incomingValues.put(fromBlock, value);
            
            // 更新操作数列表
            List<IRValue> blocks = getPredecessorBlocks();
            for (int i = 0; i < blocks.size(); i++) {
                if (blocks.get(i).equals(fromBlock)) {
                    replaceOperand(i, value);
                    break;
                }
            }
        }
    }
    
    /**
     * 获取指定基本块对应的传入值
     */
    public IRValue getIncomingValue(IRValue fromBlock) {
        return incomingValues.get(fromBlock);
    }
    
    /**
     * 获取传入值的数量
     */
    public int getIncomingValueCount() {
        return incomingValues.size();
    }
    
    /**
     * 移除指定基本块的传入值
     */
    public void removeIncomingBlock(IRValue block) {
        if (incomingValues.containsKey(block)) {
            IRValue removedValue = incomingValues.remove(block);
            
            // 更新操作数列表
            List<IRValue> blocks = new ArrayList<>(incomingValues.keySet());
            clearAllOperands();
            for (IRValue remainingBlock : blocks) {
                addOperand(incomingValues.get(remainingBlock));
            }
        }
    }
    
    /**
     * 替换传入基本块
     */
    public void replaceIncomingBlock(IRValue oldBlock, IRValue newBlock) {
        if (incomingValues.containsKey(oldBlock)) {
            IRValue value = incomingValues.remove(oldBlock);
            incomingValues.put(newBlock, value);
            
            // 更新操作数列表
            List<IRValue> blocks = getPredecessorBlocks();
            clearAllOperands();
            for (IRValue block : blocks) {
                addOperand(incomingValues.get(block));
            }
        }
    }
    
    /**
     * 判断是否所有传入值都已填充
     */
    public boolean isComplete() {
        for (IRValue value : incomingValues.values()) {
            if (value == null) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public String getOpcodeName() {
        return "phi";
    }
    
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(getName()).append(" = phi ").append(getType()).append(" ");
        
        List<IRValue> blocks = getPredecessorBlocks();
        for (int i = 0; i < blocks.size(); i++) {
            IRValue block = blocks.get(i);
            IRValue value = incomingValues.get(block);
            
            builder.append("[ ");
            if (value != null) {
                builder.append(value.getName());
            } else {
                builder.append("undef");
            }
            builder.append(", ").append(block.getName()).append(" ]");
            
            if (i < blocks.size() - 1) {
                builder.append(", ");
            }
        }
        
        return builder.toString();
    }
}