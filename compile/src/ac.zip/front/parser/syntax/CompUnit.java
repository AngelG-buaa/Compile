package front.parser.syntax;

public class CompUnit {

}
