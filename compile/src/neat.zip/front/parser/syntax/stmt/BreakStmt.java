package front.parser.syntax.stmt;


/**
 * 对应Stmt → 'break' ';'
 */
public class BreakStmt extends Stmt {
}
