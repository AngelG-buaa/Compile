package front.parser.syntax.stmt;


/**
 * 对应Stmt → 'continue' ';'
 */
public class ContinueStmt extends Stmt {
}
