package back.mips.instruction;

import back.mips.InstrM;

public class SyscallM extends InstrM {
    @Override
    public String toString() {
        return "syscall";
    }
}
