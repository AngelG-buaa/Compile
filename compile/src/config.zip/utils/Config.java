package utils;

public class Config {
    public static final boolean printCommentInMips = true;
    public static final boolean regSaveOptimizeFlag = true;
}
